﻿using System;

namespace FizzBuzzHarjoitusConsole
{
    public class FizzBuzz
    {
        public FizzBuzz()
        {
        }

        public string Luku(int syote)
        {

            if(syote % 3 == 0 && syote % 5 == 0)
            {
                return "FizzBuzz";
            }

            if(syote % 3 == 0)
            {
                return "Fizz";
            }

            if(syote % 5 == 0)
            {
                return "Buzz";
            }



            return syote.ToString();
        }

        private bool OnkoJaollinenViidellatoista(int syote)
        {
            return syote % 3 == 0 && syote % 5 == 0;
        }

        private bool OnkoJaollinenKolmella(int syote)
        {
            return syote % 3 == 0;
        }

        private bool OnkoJaollinenViidella(int syote)
        {
            return syote % 5 == 0;
        }
    }
}